
import SwiftUI

struct ContentView: View {
    @State private var timer: Timer? = nil
    @State private var elapsedTime: TimeInterval = 0
    @State private var isRunning = false
    
    
    var body: some View {
        VStack {
            Text(secondsToTimeString(seconds: elapsedTime))
                .font(.largeTitle)
                .padding()
            
            HStack {
                Button(action: {
                    if self.timer == nil {
                        self.timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
                            self.elapsedTime += 0.1
                        }
                        self.isRunning = true
                    }
                }) {
                    Text("Start")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                
                Button(action: {
                    self.timer?.invalidate()
                    self.timer = nil
                    self.isRunning = false
                }) {
                    Text("Stop")
                        .padding()
                        .background(Color.pink)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                
                Button(action: {
                    self.elapsedTime = 0
                    self.timer?.invalidate()
                    self.timer = nil
                    self.isRunning = false
                }) {
                    Text("Reset")
                        .padding()
                        .background(Color.cyan)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
        }
    }
    
    func secondsToTimeString(seconds: TimeInterval) -> String {
        
        let minutes = Int(seconds) / 60
        let seconds = Int(seconds) % 60
        
        return String(format: "%02d:%02d", minutes, seconds)
         
    }
}

    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
                
        }
    }


